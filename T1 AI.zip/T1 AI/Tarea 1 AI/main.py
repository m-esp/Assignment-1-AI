import os
import cv2
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix
from feature_extraction import extract_hog_features
from plot_utils import plot_confusion_matrix
import tensorflow as tf  
import pandas as pd
import matplotlib.pyplot as plt
import argparse

def load_data(image_dir, label_file):
    data = []
    labels = []
    with open(label_file, 'r') as file:
        for line in file:
            image_path, label = line.strip().split()
            full_image_path = os.path.join(image_dir, os.path.basename(image_path))
            image = cv2.imread(full_image_path, cv2.IMREAD_GRAYSCALE)
            if image is not None:
                data.append(image)
                labels.append(int(label))
            else:
                print(f"Warning: Image {full_image_path} could not be loaded.")
    return np.array(data), np.array(labels)

def calculate_class_accuracies(confusion_matrix):
    class_accuracies = []
    for i in range(len(confusion_matrix)):
        class_accuracy = confusion_matrix[i, i] / np.sum(confusion_matrix[i, :])
        class_accuracies.append(class_accuracy)
    return class_accuracies

def display_class_accuracies(accuracies, method):
    df = pd.DataFrame({
        'Class': list(range(10)),
        f'{method} Accuracy': accuracies
    })
    print(f"\nAccuracy by Class for {method}:\n", df)
    return df

def plot_class_accuracies(df_plain, df_hog, df_deep):
    df = pd.DataFrame({
        'Class': list(range(10)),
        'Plain': df_plain['Plain Accuracy'],
        'HOG': df_hog['HOG Accuracy'],
        'Deep': df_deep['Deep Accuracy']
    })
    
    df.plot(x='Class', kind='bar', figsize=(10, 6), color=['blue', 'green', 'red'])
    plt.title('Accuracy by Class for Different Methods')
    plt.xlabel('Class')
    plt.ylabel('Accuracy')
    plt.ylim(0, 1)
    plt.legend(loc='lower right')
    plt.grid(True)
    plt.show()

def main():
    parser = argparse.ArgumentParser(description="Run Logistic Regression on MNIST dataset with different features.")
    parser.add_argument('--data_dir', type=str, default='Tarea 1 AI/MNIST-5000', 
                        help='Base directory for the dataset (default: Tarea 1 AI/MNIST-5000)')
    args = parser.parse_args()

    base_dir = os.path.abspath(args.data_dir)
    train_image_dir = os.path.join(base_dir, 'train_images')
    valid_image_dir = os.path.join(base_dir, 'valid_images')
    train_label_file = os.path.join(base_dir, 'train.txt')
    valid_label_file = os.path.join(base_dir, 'valid.txt')

    X_train, y_train = load_data(train_image_dir, train_label_file)
    X_val, y_val = load_data(valid_image_dir, valid_label_file)

    print(f"X_train shape after processing: {X_train.shape}")
    print(f"X_val shape after processing: {X_val.shape}")

    X_train_flat = X_train.reshape(X_train.shape[0], -1)
    X_val_flat = X_val.reshape(X_val.shape[0], -1)
    scaler = StandardScaler()
    X_train_flat = scaler.fit_transform(X_train_flat)
    X_val_flat = scaler.transform(X_val_flat)

    logreg_plain = LogisticRegression(multi_class='ovr', max_iter=1000)
    logreg_plain.fit(X_train_flat, y_train)
    y_pred_plain = logreg_plain.predict(X_val_flat)
    acc_plain = accuracy_score(y_val, y_pred_plain)
    cm_plain = confusion_matrix(y_val, y_pred_plain)
    plot_confusion_matrix(cm_plain, "Confusion Matrix - Plain Representation")

    X_train_hog = extract_hog_features(X_train)
    X_val_hog = extract_hog_features(X_val)

    logreg_hog = LogisticRegression(multi_class='ovr', max_iter=1000)
    logreg_hog.fit(X_train_hog, y_train)
    y_pred_hog = logreg_hog.predict(X_val_hog)
    acc_hog = accuracy_score(y_val, y_pred_hog)
    cm_hog = confusion_matrix(y_val, y_pred_hog)
    plot_confusion_matrix(cm_hog, "Confusion Matrix - HOG Features")

    x_train_mlp = X_train_flat
    x_val_mlp = X_val_flat

    mu = np.mean(x_train_mlp, axis=0)
    x_train_mlp = x_train_mlp - mu
    x_val_mlp = x_val_mlp - mu

    mlp_model = tf.keras.Sequential([
        tf.keras.layers.Dense(256, activation='relu', input_shape=(x_train_mlp.shape[1],)),
        tf.keras.layers.Dense(128, activation='relu'),
        tf.keras.layers.Dense(10, activation='softmax')
    ])

    mlp_model.compile(optimizer='sgd', loss='categorical_crossentropy', metrics=['accuracy'])

    y_train_one_hot = tf.keras.utils.to_categorical(y_train)
    y_val_one_hot = tf.keras.utils.to_categorical(y_val)

    mlp_model.fit(x_train_mlp, y_train_one_hot, batch_size=100, epochs=20, validation_data=(x_val_mlp, y_val_one_hot))

    deep_features_train = mlp_model.predict(x_train_mlp)
    deep_features_val = mlp_model.predict(x_val_mlp)

    logreg_deep = LogisticRegression(multi_class='ovr', max_iter=1000)
    logreg_deep.fit(deep_features_train, y_train)
    y_pred_deep = logreg_deep.predict(deep_features_val)
    acc_deep = accuracy_score(y_val, y_pred_deep)
    cm_deep = confusion_matrix(y_val, y_pred_deep)
    plot_confusion_matrix(cm_deep, "Confusion Matrix - Deep Features")

    print(f'Accuracy (Plain): {acc_plain}')
    print(f'Accuracy (HOG): {acc_hog}')
    print(f'Accuracy (Deep): {acc_deep}')

    plain_class_accuracies = calculate_class_accuracies(cm_plain)
    hog_class_accuracies = calculate_class_accuracies(cm_hog)
    deep_class_accuracies = calculate_class_accuracies(cm_deep)

    df_plain = display_class_accuracies(plain_class_accuracies, "Plain")
    df_hog = display_class_accuracies(hog_class_accuracies, "HOG")
    df_deep = display_class_accuracies(deep_class_accuracies, "Deep")

    plot_class_accuracies(df_plain, df_hog, df_deep)

if __name__ == "__main__":
    main()