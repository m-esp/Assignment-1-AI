from skimage.feature import hog
from keras.layers import TFSMLayer, Input
from keras.models import Model
import tensorflow as  tf
import cv2
import numpy as np

def extract_hog_features(images):
    hog_features = []
    for image in images:
        fd = hog(image, pixels_per_cell=(8, 8),
                 cells_per_block=(2, 2), 
                 visualize=False)
        hog_features.append(fd)
    return np.array(hog_features)

def extract_deep_features(infer, images):
    # Resize images
    images_resized = np.array([cv2.resize(img, (28, 28)) for img in images])
    images_normalized = images_resized.astype('float32') / 255
    images_normalized = np.expand_dims(images_normalized, -1)

    tensor_input = tf.convert_to_tensor(images_normalized)
    predictions = infer(tensor_input)
    predictions = list(predictions.values())[0]

    return predictions.numpy()


def load_pretrained_model(model_path):
    loaded = tf.saved_model.load(model_path)
    infer = loaded.signatures['serving_default']
    return infer