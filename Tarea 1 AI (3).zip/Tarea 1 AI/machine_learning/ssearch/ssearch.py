import tensorflow as tf
import numpy as np
import skimage.io as io
import os

class SSearch:
    def __init__(self, model_file, layer_name):
        self.sim = None
        self.sim_file = 'sim_emnist.npy'
        self.fv_file = 'fv_emnist.npy'
        self.lbl_file = 'lbl_emnist.npy'

        # Load the model using TFSMLayer
        print("Loading model with TFSMLayer...")
        try:
            self.model = tf.keras.layers.TFSMLayer(model_file, call_endpoint='serving_default')
        except Exception as e:
            print(f"An error occurred while loading the model: {e}")
            raise

        # Check if mean.npy exists, if not, calculate it later
        if os.path.exists('mean.npy'):
            self.mu = np.load('mean.npy')
        else:
            self.mu = None # Calculte later

    def load_catalog(self, data_dir, label_file):
        data = []
        labels = []
        with open(label_file, 'r') as file:
            for line in file:
                image_path, label = line.strip().split()
                full_image_path = os.path.join(data_dir, os.path.basename(image_path))
                image = io.imread(full_image_path, as_gray=True)
                if image is not None:
                    data.append(image)
                    labels.append(int(label))
                else:
                    print(f"Warning: Image {full_image_path} could not be loaded.")
        self.data_catalog = np.array(data, dtype=np.float32) 
        self.data_labels = np.array(labels)
        print(f"Loaded {self.data_catalog.shape[0]} images with labels")

        # Calculate mean if it wasn't before
        if self.mu is None:
            self.mu = np.mean(self.data_catalog, axis=0)
            np.save('mean.npy', self.mu)
            print("Mean calculated and saved as 'mean.npy'")

    def prepare_data(self, data):
        if data.ndim == 3:
            prepared_data = np.expand_dims(data, axis=-1) 
        elif data.ndim == 4 and data.shape[-1] != 1:
            prepared_data = data[:, :, :, :1] 
        else:
            prepared_data = data
        
        prepared_data = prepared_data - self.mu  # Substract the mean
        return prepared_data

    def compute_features(self, data):
        data = self.prepare_data(data)
        # I used this to debug, had a LOT of issues here
        print(f"Input data shape before model: {data.shape}")
        try:
            features = self.model(data)
            fv = features['tf.nn.softmax'].numpy() 
            print('FV-shape {}'.format(fv.shape))
            np.save(self.fv_file, fv)
            np.save(self.lbl_file, self.data_labels)
            print('FV saved at {}'.format(self.fv_file))
            print('Labels saved at {}'.format(self.lbl_file))
            return fv
        except Exception as e:
            print(f"An error occurred while computing features: {e}")
            raise

    def compute_features_on_catalog(self):
        return self.compute_features(self.data_catalog)

    def ssearch_all(self):
        if not isinstance(self.sim, np.ndarray):
            self.compute_features_on_catalog()
            fv = self.fv
            normfv = np.linalg.norm(fv, ord=2, axis=1, keepdims=True)
            fv = fv / normfv
            self.sim = np.matmul(fv, np.transpose(fv))
            np.save(self.sim_file, self.sim)
            print('{} saved'.format(self.sim_file))

    def random_save_example(self, n):
        ids = np.random.permutation(self.sim.shape[0])[:n]
        for id_image in ids:
            sim_q = self.sim[id_image, :]
            print('label {}'.format(self.data_labels[id_image]))
            sort_idx = np.argsort(-sim_q)[:10]
            print(self.data_labels[sort_idx])
            image = self.get_collage(sort_idx)
            io.imsave('result_{}.png'.format(id_image), image)

    def get_collage(self, sort_idx):
        size = 28
        n = 10
        image = np.ones((size, n * size), dtype=np.uint8) * 255
        for i in np.arange(n):
            image[:, i * size:(i + 1) * size] = self.data_catalog[sort_idx[i], :, :]
        return image
